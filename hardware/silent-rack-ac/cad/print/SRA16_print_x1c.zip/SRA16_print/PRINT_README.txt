CP-SRA16-PRT-001 rev A - SRA-16 printed parts, STL set for the Bambu Lab X1 Carbon

Every STL is already oriented for printing (flat face on the plate, no supports needed) and sits
on z = 0. Units: mm. Import, keep the orientation, add the brim below, slice. Full notes:
hardware/silent-rack-ac/docs/PRINTED_PARTS.md

PRINT G1 AND G2 FIRST. G1 must slide over the AC exhaust spigot with light friction; the 150 mm
duct must slide over G2. If not, fix the fit before printing the elbow and spigot.
Plates are numbered in print order.

PETG - cold side: hood, collar, keepers (water-resistant, tough; carries 12-18 degC air)
  Filament        Bambu PETG HF (or any PETG), dried
  Nozzle / layer  0.4 mm / 0.20 mm (0.6 mm / 0.30 mm halves the hood time)
  Walls           4 wall loops, 5 top + 5 bottom layers: the 4 mm walls print solid
  Infill          15% gyroid (only the thick spots use it)
  Plate           Textured PEI, no glue
  Brim            5 mm on the hood ends and the collar; 8 mm on the two middle channels (tall, narrow)
  Supports        none - every piece is oriented to print without them
  Cooling         profile default; open the top glass on a hot day (PETG clogs in a warm chamber)

ASA - hot side: exhaust elbow, wall spigot and their gauges (exhaust air up to about 60 degC)
  Filament        Bambu ASA (or any ASA), dried
  Nozzle / layer  0.4 mm / 0.20 mm
  Walls           4 wall loops, 5 top + 5 bottom layers
  Infill          15% gyroid
  Plate           Textured PEI + glue stick
  Brim            5 mm on everything except the gauges
  Supports        none
  Chamber         door and lid closed, chamber warm before starting (warps less)

Plates:
   1  ASA   G1  (~25 g, ~1 h)
   2  ASA   G2  (~29 g, ~1 h)
   3  PETG  P2-1  (~125 g, ~3 h)
   4  PETG  P2-2  (~120 g, ~3 h)
   5  PETG  P1-1, P1-2a, P3-1, P3-1  (~550 g, ~14 h)
   6  PETG  P1-3, P1-2b  (~559 g, ~14 h)
   7  ASA   P4-1  (~321 g, ~10 h)
   8  ASA   P4-2  (~319 g, ~9 h)
   9  ASA   P5-1  (~246 g, ~7 h)
  10  ASA   P5-2  (~114 g, ~4 h)

Pieces:
  P1-1   x1  PETG  Hood body - left end                              75 x   231 x   181 mm   end wall on the plate, tongue up
  P1-2a  x1  PETG  Hood body - middle, front channel                 75 x    63 x   181 mm   rebate end on the plate, tongue up
  P1-2b  x1  PETG  Hood body - middle, rear channel                  75 x   111 x   181 mm   rebate end on the plate, tongue up
  P1-3   x1  PETG  Hood body - right end                             75 x   231 x   171 mm   end wall on the plate
  P2-1   x1  PETG  Drop collar - left half                          216 x   166 x    31 mm   lip on the plate
  P2-2   x1  PETG  Drop collar - right half                         206 x   166 x    31 mm   lip on the plate
  P3-1   x2  PETG  Collar keeper                                     38 x    12 x    10 mm   arm on the plate, print 2
  P4-1   x1  ASA   Exhaust elbow - inlet half (socket)              159 x   185 x   197 mm   socket on the plate, tongue up
  P4-2   x1  ASA   Exhaust elbow - outlet half (spigot)             158 x   179 x   206 mm   male spigot on the plate, rebate up
  P5-1   x1  ASA   Wall spigot - flange + inner tube                230 x   230 x    50 mm   flange face (outside) on the plate
  P5-2   x1  ASA   Wall spigot - outer tube                         153 x   153 x    59 mm   hose end on the plate, tongue up
  G1     x1  ASA   Gauge - elbow socket over the AC spigot          159 x   159 x    12 mm   print first
  G2     x1  ASA   Gauge - male spigot into the 150 duct            149 x   149 x    15 mm   print first
